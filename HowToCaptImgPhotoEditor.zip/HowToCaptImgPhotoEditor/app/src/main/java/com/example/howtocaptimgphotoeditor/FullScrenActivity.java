package com.example.howtocaptimgphotoeditor;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.dsphotoeditor.sdk.activity.DsPhotoEditorActivity;
import com.dsphotoeditor.sdk.utils.DsPhotoEditorConstants;

public class FullScrenActivity extends AppCompatActivity {

    private final int IMAGE_REQUEST_CODE = 200;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_scren);


        ImageView imageView = findViewById(R.id.image_view);



        Button editButton = findViewById(R.id.editButton);

        Intent i = getIntent();
        int position = i.getExtras().getInt("id");


        // Appeler l'imageAdapter de la class

        ImageAdapter imageAdapter = new ImageAdapter(this);

        // Voir la position de l'image en cliquant sur l'image
        imageView.setImageResource(imageAdapter.imageArray[position]);


        // Boutton d'appel pour editButton
        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Uri uri = Uri.parse("android.resource://com.example.howtocaptimgphotoeditor/"+ imageAdapter.getItem(position));
                Intent dsPhotoEditorIntent = new Intent(FullScrenActivity.this, DsPhotoEditorActivity.class);
                dsPhotoEditorIntent.setData(uri);
                dsPhotoEditorIntent.putExtra(DsPhotoEditorConstants.DS_PHOTO_EDITOR_OUTPUT_DIRECTORY, "YOUR_OUTPUT_IMAGE_FOLDER");
                int[] toolsToHide = {DsPhotoEditorActivity.TOOL_ORIENTATION,
                        DsPhotoEditorActivity.TOOL_CONTRAST,
                        DsPhotoEditorActivity.TOOL_EXPOSURE,
                        DsPhotoEditorActivity.TOOL_FILTER,
                        DsPhotoEditorActivity.TOOL_FRAME,
                        DsPhotoEditorActivity.TOOL_PIXELATE,
                        DsPhotoEditorActivity.TOOL_ROUND,
                        DsPhotoEditorActivity.TOOL_SATURATION,
                        DsPhotoEditorActivity.TOOL_SHARPNESS,
                        DsPhotoEditorActivity.TOOL_STICKER,
                        DsPhotoEditorActivity.TOOL_VIGNETTE,
                        DsPhotoEditorActivity.TOOL_WARMTH,
                        DsPhotoEditorActivity.TOOL_TEXT
                };
                dsPhotoEditorIntent.putExtra(DsPhotoEditorConstants.DS_PHOTO_EDITOR_TOOLS_TO_HIDE, toolsToHide);
                //noinspection deprecation
                startActivityForResult(dsPhotoEditorIntent, IMAGE_REQUEST_CODE);


            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode== IMAGE_REQUEST_CODE){
            if (data.getData()!= null){
                Intent intent = new Intent(FullScrenActivity.this, EditedImageActivity.class);
                intent.setData(data.getData());
                startActivity(intent);

            }
        }
    }
}