package com.example.howtocaptimgphotoeditor;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;

public class EditedImageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edited_image);

        AppCompatImageView image = findViewById(R.id.edited_image);
        image.setImageURI(getIntent().getData());
    }
}
